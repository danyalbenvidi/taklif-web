function Run()
{
    let offset = 0, count,boardArray;
    do
    {
        boardArray = GetEmptyBoard();
        boardArray[offset % 8][offset / 8] = true;
        count = 0;
        for (let y = 0; y < 8; y++)
        {
            for (let x = 0; x < 8; x++)
            {
                boardArray[x][y] = CheckForCollision(x, y,boardArray);
                if (boardArray[x][y])
                {
                    count++;
                }
            }
        }
        offset++;
    }while (count <8);
    PrintBoard(boardArray);
}
function GetEmptyBoard()
{
    let board = new Array(8);
    for(let y = 0;y<8;y++)
    {
        let row = new Array(8);
        for (let x=0;x<8;x++)
        {
            row[x] = false;
        }
        board[y] = row;
    }
    return board;
}
function CheckForCollision(x,y,board)
{
// right
    for (let i = x + 1; i < 8; i++)
    {
        if (board[i][y])
            return false;
    }
    //left
    for (let i = x - 1; i >= 0; i--)
    {
        if (board[i][y])
            return false;
    }
    //down
    for (let i = y + 1; i < 8; i++)
    {
        if (board[x][i])
            return false;
    }
    //up
    for (let i = y - 1; i >= 0; i--)
    {
        if (board[x][i])
            return false;
    }
    //diagonal downright
    for (let i = x + 1, j = y + 1; i < 8 && j < 8; i++, j++)
    {
        if (board[i][j])
            return false;
    }
    //diagonal upright
    for (let i = x + 1, j = y - 1; i < 8 && j >= 0; i++, j--)
    {
        if (board[i][j])
            return false;
    }
    //diagonal downleft
    for (let i = x - 1, j = y + 1; i >= 0 && j < 8; i--, j++)
    {
        if (board[i][j])
            return false;
    }
    //diagonal upleft
    for (let i = x - 1, j = y - 1; i >= 0 && j >= 0; i--, j--)
    {
        if (board[i][j])
            return false;
    }
    return true;
}
function PrintBoard(board)
{
    let cellColor = "white";
    let htmlBoard = "<div class='board'>";
    
    for (let y = 0;y<8;y++)
    {
        let htmlRow = "<div class='boardRow'>";
        if(y % 2 == 1)
        {
            cellColor= "black";
        }
        else{
            cellColor = "white";
        }
        for(let x=0;x<8;x++)
        {
            let cell = "<div class='cell ";
            cell += cellColor
            cell += "'>";
            if (cellColor == "black")
                cellColor = "white";
            else
                cellColor = "black";
            
            if (board[x][y]){
                cell += "<img src='img/queen.png'>";
            }
            cell+= "</div>";
            htmlRow+= cell;
        }
        htmlRow+= "</div>";
        htmlBoard += htmlRow;
    }
    htmlBoard += "</div>";
    document.body.innerHTML += htmlBoard;
}